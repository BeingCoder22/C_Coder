#include<stdio.h>

int main()
{
	printf("this is test code\n");
	printf("added something\n");
<<<<<<< HEAD
	printf("added by newc branch\n");
=======
	printf("hi all\n");
>>>>>>> 485a2178da1d3db0e16a5e50f595324037784e0e
return 0;
}
