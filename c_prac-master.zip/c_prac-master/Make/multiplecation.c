float mul(int a,int b)
{
	float res;
	res = a*b;
	return res;
}
